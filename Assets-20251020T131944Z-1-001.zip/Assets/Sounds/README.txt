I don't remember where I got all of these sounds from, so don't use them outside of this project.


Caravan_mono.wav ℗2016 Ole E. Flaten

 Harvard cs50: https://cs50.harvard.edu/games/weeks/
paddle_hit.wav
score.wav
wall_hit.wav
score_flappy.wav
hurt.wav
jump.wav
marios_way.mp3
explosion8bit.wav
brick-hit-1.wav
brick-hit-2.wav
confirm.wav
high_score.wav
hurt_hard.wav
music.wav
no-select.wav
pause.wav
recover.wav
select.wav
victory.wav